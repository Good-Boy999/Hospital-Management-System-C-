#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;


struct Doctor {
    int id;
    string name;
    string specialty;
    string startTime;
    string endTime;
    int patientCount = 0; 
};


struct Patient {
    int id;
    string name;
    int age;
    string disease;
};


struct Appointment {
    int id;
    int patientId;
    int doctorId;
};


string toLowerCase(const string& str) {
    string result = str;
    transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}


void createDoctorsFile() {
    ofstream file("doctors.txt");
    file << "1 Dr.John Cardiologist 09:00AM 05:00PM\n";
    file << "2 Dr.Alice Neurologist 10:00AM 06:00PM\n";
    file << "3 Dr.Bob Pediatrician 08:00AM 04:00PM\n";
    file << "4 Dr.Carol Orthopedic_Surgeon 11:00AM 07:00PM\n";
    file << "5 Dr.Eve Dermatologist 09:00AM 05:00PM\n";
    file << "6 Dr.Frank Cardiologist 01:00PM 09:00PM\n";
    file << "7 Dr.Davis Neurologist 09:00AM 05:00PM\n";
    file << "8 Dr.Miller Pediatrician 10:00AM 06:00PM\n";
    file << "9 Dr.Anderson Orthopedic Surgeon 08:00AM 04:00PM\n";
    file << "10 Dr.Thomas Dermatologist 11:00AM 07:00PM\n";
    file.close();
}


void createAppointmentsFile() {
    ofstream file("appointments.txt");
    file.close(); 
}


void addPatient(vector<Patient>& patients) {
    Patient patient;
    patient.id = patients.size() + 1;  
    cout << "Enter patient name: ";
    getline(cin, patient.name);
    cout << "Enter patient age: ";
    cin >> patient.age;
    cin.ignore();  
    cout << "Enter diseases/symptoms: ";
    getline(cin, patient.disease);

    patients.push_back(patient);
    cout << "Patient added successfully with ID: " << patient.id << "\n";

    
    ofstream file("patients.txt", ios::app);
    file << patient.id << " " << patient.name << " " << patient.age << " " << patient.disease << "\n";
    file.close();
}

vector<Doctor> readDoctorsFromFile() {
    ifstream file("doctors.txt");
    vector<Doctor> doctors;

    Doctor doctor;
    while (file >> doctor.id >> ws && getline(file, doctor.name, ' ')
        >> doctor.specialty >> doctor.startTime >> doctor.endTime) {
        doctors.push_back(doctor);
    }
    file.close();
    return doctors;
}


void addAppointment(vector<Appointment>& appointments, vector<Doctor>& doctors, vector<Patient>& patients) {
    string disease;
    int age;
    cout << "Enter patient's diseases/symptoms: ";
    getline(cin, disease);
    cout << "Enter patient's age: ";
    cin >> age;
    cin.ignore();  

 
    string lowerDisease = toLowerCase(disease);
    vector<Doctor> matchingDoctors;
    for (const auto& doc : doctors) {
        string lowerSpecialty = toLowerCase(doc.specialty);
        bool match = false;

        if (lowerSpecialty == "cardiologist" && (lowerDisease.find("chest pain") != string::npos ||
            lowerDisease.find("shortness of breath") != string::npos ||
            lowerDisease.find("coughing") != string::npos ||
            lowerDisease.find("swelling") != string::npos ||
            lowerDisease.find("fatigue") != string::npos ||
            lowerDisease.find("fast heartbeat") != string::npos)) {
            match = true;
        }
        else if (lowerSpecialty == "neurologist" && (lowerDisease.find("muscle weakness") != string::npos ||
            lowerDisease.find("dizziness") != string::npos ||
            lowerDisease.find("tingling") != string::npos ||
            lowerDisease.find("confusion") != string::npos ||
            lowerDisease.find("seizures") != string::npos ||
            lowerDisease.find("severe pain") != string::npos)) {
            match = true;
        }
        else if (lowerSpecialty == "pediatrician" && (age < 18)) {
            match = true;
        }
        else if (lowerSpecialty == "orthopedic_surgeon" && (lowerDisease.find("pain") != string::npos ||
            lowerDisease.find("swelling") != string::npos ||
            lowerDisease.find("stiff joints") != string::npos ||
            lowerDisease.find("achy joints") != string::npos ||
            lowerDisease.find("muscle injuries") != string::npos ||
            lowerDisease.find("infection") != string::npos)) {
            match = true;
        }
        else if (lowerSpecialty == "dermatologist" && (lowerDisease.find("skin cancer") != string::npos ||
            lowerDisease.find("acne") != string::npos ||
            lowerDisease.find("rash") != string::npos ||
            lowerDisease.find("hives") != string::npos ||
            lowerDisease.find("scars") != string::npos ||
            lowerDisease.find("eczema") != string::npos ||
            lowerDisease.find("psoriasis") != string::npos)) {
            match = true;
        }

        if (match) {
            matchingDoctors.push_back(doc);
        }
    }

    if (matchingDoctors.empty()) {
        cout << "No doctors available for the specified disease or age.\n";
        return;
    }

    cout << "Available Doctors:\n";
    for (const auto& doc : matchingDoctors) {
        cout << "ID: " << doc.id
             << ", Name: " << doc.name
             << ", Specialty: " << doc.specialty
             << ", Available From: " << doc.startTime
             << " To: " << doc.endTime << endl;
    }

    int doctorId;
    cout << "Enter the ID of the doctor you want to make an appointment with: ";
    cin >> doctorId;
    cin.ignore();  

    
    auto it = find_if(matchingDoctors.begin(), matchingDoctors.end(), [doctorId](const Doctor& d) { return d.id == doctorId; });
    if (it == matchingDoctors.end()) {
        cout << "Invalid doctor ID.\n";
        return;
    }

    
    Appointment appointment;
    appointment.id = appointments.size() + 1;  
    appointment.patientId = patients.size();  
    appointment.doctorId = doctorId;

    appointments.push_back(appointment);

    
    ofstream file("appointments.txt", ios::app);
    file << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Doctor ID: " << appointment.doctorId << "\n";
    file.close();

    cout << "Appointment added successfully.\n";
}


void viewAppointments() {
    ifstream file("appointments.txt");
    cout << "List of Appointments:\n";

    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
}



void deletePatient(vector<Patient>& patients, int id) {
    auto it = remove_if(patients.begin(), patients.end(), [id](const Patient& p) { return p.id == id; });
    if (it != patients.end()) {
        patients.erase(it, patients.end());
        cout << "Patient removed.\n";

    
        ofstream file("patients.txt");
        for (const auto& patient : patients) {
            file << patient.id << " " << patient.name << " " << patient.age << " " << patient.disease << "\n";
        }
        file.close();
    } else {
        cout << "Patient not found.\n";
    }
}



void deleteAppointment(int appointmentId) {
    ifstream file("appointments.txt");
    vector<Appointment> appointments;
    Appointment appointment;

    while (file >> appointment.id >> appointment.patientId >> appointment.doctorId) {
        if (appointment.id != appointmentId) {
            appointments.push_back(appointment);
        }
    }
    file.close();

    ofstream outFile("appointments.txt");
    for (const auto& appt : appointments) {
        outFile << appt.id << " " << appt.patientId << " " << appt.doctorId << "\n";
    }
    outFile.close();

    cout << "Appointment deleted.\n";
}


void addBillingRecord(const vector<Patient>& patients) {
    int patientId;
    double appointmentFee, medicinePrice, total;

    cout << "Enter patient ID: ";
    cin >> patientId;

   
    bool patientFound = false;
    for (const auto& patient : patients) {
        if (patientId == &patient - &patients[0] + 1) {  
            patientFound = true;
            break;
        }
    }

    if (!patientFound) {
        cout << "Patient not found.\n";
        return;
    }

    cout << "Enter appointment fee ($): ";
    cin >> appointmentFee;
    cout << "Enter medicine price ($): ";
    cin >> medicinePrice;

    total = appointmentFee + medicinePrice;

    
    ofstream file("billing.txt", ios::app);
    file << "Patient ID: " << patientId
         << ", Appointment Fee: $" << appointmentFee
         << ", Medicine Price: $" << medicinePrice
         << ", Total: $" << total << endl;
    file.close();

    cout << "Billing record added. Total: $" << total << endl;
}





int main() {
    vector<Patient> patients;
    vector<Doctor> doctors = readDoctorsFromFile();
    vector<Appointment> appointments;

    if (doctors.empty()) {
        createDoctorsFile();
        doctors = readDoctorsFromFile();
    }

    while (true) {
        cout << "\nHospital Management System\n";
        cout << "1. Add Patient\n";
        cout << "2. View Patients\n";
        cout << "3. Add Appointment\n";
        cout << "4. View Appointments\n";
        cout << "5. Delete Patient\n";
        cout << "6. Delete Appointment\n";
        cout << "7. Add Billing Record\n";
        cout << "8. Exit\n";
        cout << "Choose an option: ";
        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            addPatient(patients);
        } else if (choice == 2) {
            for (const auto& patient : patients) {
                cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << ", Diseases/Symptoms " << patient.disease << "\n";
            }
        } else if (choice == 3) {
                
                addAppointment(appointments, doctors, patients);
            
        } else if (choice == 4) {
            viewAppointments();
        } else if (choice == 5) {
            int patientId;
            cout << "Enter patient ID to delete: ";
            cin >> patientId;
            deletePatient(patients, patientId);
        } else if (choice == 6) {
            int appointmentId;
            cout << "Enter appointment ID to delete: ";
            cin >> appointmentId;
            cin.ignore();
            deleteAppointment(appointmentId);
        } else if (choice == 7) {
            addBillingRecord(patients);
        } else if (choice == 8) {
            break;
        } else {
            cout << "Invalid choice. Try again.\n";
        }
    }
    return 0;
}

